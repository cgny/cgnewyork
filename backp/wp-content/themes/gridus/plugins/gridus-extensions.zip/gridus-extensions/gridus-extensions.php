<?php
/**
 * Gridus Extensions
 *
 * @author    Neuethemes
 *
 * Plugin Name: Gridus Extensions
 * Description: Custom shortcodes and widgets.
 * Version:     0.3.3
 * Author:      Neuethemes
 */

define ('GRIDUS_EXT_DIR', trailingslashit(plugin_dir_path(__FILE__)));
define ('GRIDUS_EXT_URL', trailingslashit(plugin_dir_url(__FILE__)));

// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}

/**
 * Gridus shortcodes
 */
if (!function_exists('gridus_register_shorcodes')) {
    function gridus_register_shorcodes()
    {
        require_once GRIDUS_EXT_DIR . 'shortcodes/blog.php';
        require_once GRIDUS_EXT_DIR . 'shortcodes/contact.php';
        require_once GRIDUS_EXT_DIR . 'shortcodes/countblock.php';
        require_once GRIDUS_EXT_DIR . 'shortcodes/dividewhite.php';
        require_once GRIDUS_EXT_DIR . 'shortcodes/googlemap.php';
        require_once GRIDUS_EXT_DIR . 'shortcodes/grid.php';
        require_once GRIDUS_EXT_DIR . 'shortcodes/infoblock.php';
        require_once GRIDUS_EXT_DIR . 'shortcodes/portfolio.php';
        require_once GRIDUS_EXT_DIR . 'shortcodes/progressblock.php';
        require_once GRIDUS_EXT_DIR . 'shortcodes/testimonial.php';
        require_once GRIDUS_EXT_DIR . 'shortcodes/timeline.php';
    }
    add_action('init', 'gridus_register_shorcodes', 100);
}

/**
 * Gridus widgets
 */
if (!function_exists('gridus_register_widgets')) {
    function gridus_register_widgets()
    {
        require_once GRIDUS_EXT_DIR . 'widgets/social.php';
    }
    add_action( 'widgets_init', 'gridus_register_widgets' );
}

/**
 * Gridus Demo Content Page
 */
if (!function_exists('gridus_register_demo_content_page')) {
    require_once GRIDUS_EXT_DIR . 'pages/demo-content.php';
    require_once GRIDUS_EXT_DIR . 'demo-content/importer.php';

    function gridus_register_demo_content_page() {
        add_submenu_page( 'themes.php', esc_html__('Demo Content', 'gridus'), esc_html__('Demo Content', 'gridus'), 'import', 'demo-content-page', 'demo_content_page_callback' );
    }

    add_action('admin_menu', 'gridus_register_demo_content_page');
}

/**
 * Gridus Rate Theme Page
 */
if (!function_exists('gridus_register_rate_theme_page')) {
    require_once GRIDUS_EXT_DIR . 'pages/rate-theme.php';

    function gridus_register_rate_theme_page() {
        add_menu_page('Rate the Theme', 'Rate the Theme', 'manage_options', 'rate_theme', 'gridus_rate_theme_page_callback', 'dashicons-star-filled');
    }

    add_action('admin_menu', 'gridus_register_rate_theme_page');
}

/**
 * Custom post types
 */
if (!function_exists('gridus_register_custom_post_types')) {
    function gridus_register_custom_post_types()
    {
        register_post_type('timeline', array(
            'labels' => array(
                'name' => esc_html__('Professional Timeline', 'gridus'),
                'singular_name' => esc_html__('Item', 'gridus'),
                'menu_name' => esc_html__('Professional Timeline', 'gridus'),
                'all_items' => esc_html__('All Timeline Items', 'gridus'),
                'add_new_item' => esc_html__( 'Add New Item', 'gridus' ),
            ),
            'description' => esc_html__('Custom type for Gridus Professional Timeline', 'gridus'),
            'public' => true,
            'publicly_queryable' => true,
            'exclude_from_search' => true,
            'show_ui' => true,
            'show_in_menu' => true,
            'menu_position' => 4,
            'menu_icon' => 'dashicons-chart-bar',
            'hierarchical' => false,
            'taxonomies' => array('category'),
            'supports' => array('title', 'editor', 'thumbnail'),
            'rewrite' => true,
            'query_var' => true,
            'show_in_nav_menus' => false,
        ));
    }
    add_action( 'init', 'gridus_register_custom_post_types', 100 );
}

/**
 * Custom date format
 */
if (!function_exists('gridus_date_format')) {

    function gridus_date_format( $format_to, $value ) {
        if ( empty( $value ) ) {
            return '...';
        }

        $year  = substr( $value, 0, 4 );
        $month = substr( $value, 4, 2 );
        $day   = substr( $value, 6, 2 );

        $result = date_i18n( $format_to, strtotime($year . '/' . $month . '/' . $day) );

        return $result;
    }
}

require_once GRIDUS_EXT_DIR . 'menu-icons-flaticon/menu-icons-flaticon.php';

/**
 * Enqueue admin scripts
 */
function gridus_extensions_admin_scripts() {

    // Add the color picker css file
    wp_enqueue_style( 'wp-color-picker' );

    wp_enqueue_style( 'gridus-extensions', GRIDUS_EXT_URL . '/assets/css/style.css', array(), '20150825' );
    wp_enqueue_script( 'gridus-extensions', GRIDUS_EXT_URL . '/assets/js/script.js', array( 'wp-color-picker' ), false, true );
}
add_action( 'admin_enqueue_scripts', 'gridus_extensions_admin_scripts');

/**
 * Gridus nav menu color field
 */
function gridus_nav_menu_color( $id, $item, $depth, $args ) {
    $color = get_post_meta( $item->ID, 'menu-color', true );
    ?>
    <div class="ge-nav-menu-color description-wide">
        <p class="description">
            <label for="gridus-menu-colors">Color:</label>
            <input class="ge-color-field" name="menu-colors[<?php echo json_encode( $item->ID ); ?>]" value="<?php echo $color; ?>">
        </p>
    </div>
    <?php
}
add_filter( 'wp_nav_menu_item_custom_fields', 'gridus_nav_menu_color', 11, 4 );

/**
 * Gridus nav menu color update
 */
function gridus_nav_menu_color_update( $menu_id, $menu_item_db_id, $menu_item_args ) {
    if ( !empty($_POST['menu-colors']) ) {
        $color = $_POST['menu-colors'][ $menu_item_db_id ];
        if ( preg_match('|^#([A-Fa-f0-9]{3}){1,2}$|', $color ) ) {
            update_post_meta( $menu_item_db_id, 'menu-color', $color );
        } elseif ( empty($color) ) {
            update_post_meta( $menu_item_db_id, 'menu-color', $color );
        }
    }
}
add_action( 'wp_update_nav_menu_item', 'gridus_nav_menu_color_update', 10, 3 );

/**
 * Gridus session
 */
function gridusStartSession() {
    if ( ! session_id() ) {
        session_start();
    }
    if ( !isset($_SESSION['gridusSession']) ) {
        $_SESSION['gridusSession'] = array();
    }
}

add_action( 'init', 'gridusStartSession', 1 );