<?php
/**
 * Flat Icons
 */
class Icon_Picker_Type_Flaticon extends Icon_Picker_Type_Font {

	/**
	 * Icon type ID
	 *
	 * @since  0.1.0
	 * @access protected
	 * @var    string
	 */
	protected $id = 'flaticon';

	/**
	 * Icon type name
	 *
	 * @since  0.1.0
	 * @access protected
	 * @var    string
	 */
	protected $name = 'Flaticon';

	/**
	 * Icon type version
	 *
	 * @since  0.1.0
	 * @access protected
	 * @var    string
	 */
	protected $version = '1.0';

	/**
	 * Stylesheet ID
	 *
	 * @since  0.1.0
	 * @access protected
	 * @var    string
	 */
	protected $stylesheet_id = 'flaticon';

	/**
	 * Get stylesheet URI
	 *
	 * @since  0.2.0
	 * @return string
	 */
	public function get_stylesheet_uri() {
		return get_template_directory_uri() . '/assets/vendor/flaticons/flaticon.css';
	}

	/**
	 * Get icon groups
	 *
	 * @since  0.1.0
	 * @return array
	 */
	public function get_groups() {
		$groups = array();

		/**
		 * Filter genericon groups
		 *
		 * @since 0.1.0
		 * @param array $groups Icon groups.
		 */
		$groups = apply_filters( 'icon_picker_fa_groups', $groups );

		return $groups;
	}


	/**
	 * Get icon names
	 *
	 * @since  0.1.0
	 * @return array
	 */
	public function get_items() {
		$items = array(
			array(
				'id'    => 'flaticon-arrows',
				'name'  => 'Arrows',
			),
			array(
				'id'    => 'flaticon-arrows-1',
				'name'  => 'Arrows 1',
			),
			array(
				'id'    => 'flaticon-arrows-2',
				'name'  => 'Arrows 2',
			),
			array(
				'id'    => 'flaticon-arrows-3',
				'name'  => 'Arrows 3',
			),
			array(
				'id'    => 'flaticon-arrows-4',
				'name'  => 'Arrows 4',
			),
			array(
				'id'    => 'flaticon-behance7',
				'name'  => 'Behance',
			),
			array(
				'id'    => 'flaticon-bird97',
				'name'  => 'Bird',
			),
			array(
				'id'    => 'flaticon-book-bag2',
				'name'  => 'Bag',
			),
			array(
				'id'    => 'flaticon-circle',
				'name'  => 'Circle',
			),
			array(
				'id'    => 'flaticon-circle-1',
				'name'  => 'Circle 1',
			),
			array(
				'id'    => 'flaticon-circle-2',
				'name'  => 'Circle 2',
			),
			array(
				'id'    => 'flaticon-circle-3',
				'name'  => 'Circle 3',
			),
			array(
				'id'    => 'flaticon-circle-4',
				'name'  => 'Circle 4',
			),
			array(
				'id'    => 'flaticon-circle-5',
				'name'  => 'Circle 5',
			),
			array(
				'id'    => 'flaticon-circle-6',
				'name'  => 'Circle 6',
			),
			array(
				'id'    => 'flaticon-clipboard80',
				'name'  => 'Clipboard',
			),
			array(
				'id'    => 'flaticon-clock',
				'name'  => 'Clock',
			),
			array(
				'id'    => 'flaticon-clocks18',
				'name'  => 'Clocks',
			),
			array(
				'id'    => 'flaticon-download149',
				'name'  => 'Download',
			),
			array(
				'id'    => 'flaticon-download167',
				'name'  => 'Download',
			),
			array(
				'id'    => 'flaticon-earphones18',
				'name'  => 'Earphones',
			),
			array(
				'id'    => 'flaticon-facebook45',
				'name'  => 'Facebook',
			),
			array(
				'id'    => 'flaticon-github-logo-silhouette-in-a-square',
				'name'  => 'GitHub',
			),
			array(
				'id'    => 'flaticon-google111',
				'name'  => 'Google',
			),
			array(
				'id'    => 'flaticon-graduation61',
				'name'  => 'Graduation',
			),
			array(
				'id'    => 'flaticon-graduation9',
				'name'  => 'Graduation',
			),
			array(
				'id'    => 'flaticon-identification28',
				'name'  => 'Identification',
			),
			array(
				'id'    => 'flaticon-graduation9',
				'name'  => 'Graduation',
			),
			array(
				'id'    => 'flaticon-insignia',
				'name'  => 'Insignia',
			),
			array(
				'id'    => 'flaticon-instagram14',
				'name'  => 'Instagram',
			),
			array(
				'id'    => 'flaticon-internet',
				'name'  => 'Internet',
			),
			array(
				'id'    => 'flaticon-linkedin22',
				'name'  => 'Linkedin',
			),
			array(
				'id'    => 'flaticon-odnolassniki2',
				'name'  => 'Odnolassniki',
			),
			array(
				'id'    => 'flaticon-painting62',
				'name'  => 'Painting',
			),
			array(
				'id'    => 'flaticon-paper40',
				'name'  => 'Paper',
			),
			array(
				'id'    => 'flaticon-pens15',
				'name'  => 'Pens',
			),
			array(
				'id'    => 'flaticon-photo246',
				'name'  => 'Photo',
			),
			array(
				'id'    => 'flaticon-photography39',
				'name'  => 'Photography',
			),
			array(
				'id'    => 'flaticon-pie-graph',
				'name'  => 'Pie graph',
			),
			array(
				'id'    => 'flaticon-pinterest28',
				'name'  => 'Pinterest',
			),
			array(
				'id'    => 'flaticon-placeholders4',
				'name'  => 'Placeholders',
			),
			array(
				'id'    => 'flaticon-profile5',
				'name'  => 'Profile',
			),
			array(
				'id'    => 'flaticon-shopping-carts6',
				'name'  => 'Shopping carts',
			),
			array(
				'id'    => 'flaticon-sign',
				'name'  => 'Sign',
			),
			array(
				'id'    => 'flaticon-soundcloud8',
				'name'  => 'Soundcloud',
			),
			array(
				'id'    => 'flaticon-stack-overflow',
				'name'  => 'Stack Overflow',
			),
			array(
				'id'    => 'flaticon-stats47',
				'name'  => 'Stats',
			),
			array(
				'id'    => 'flaticon-stats48',
				'name'  => 'Stats',
			),
			array(
				'id'    => 'flaticon-symbol',
				'name'  => 'Symbol',
			),
			array(
				'id'    => 'flaticon-three',
				'name'  => 'Three',
			),
			array(
				'id'    => 'flaticon-three-1',
				'name'  => 'Three 1',
			),
			array(
				'id'    => 'flaticon-three-2',
				'name'  => 'Three 2',
			),
			array(
				'id'    => 'flaticon-tool',
				'name'  => 'Tool',
			),
			array(
				'id'    => 'flaticon-tool-1',
				'name'  => 'Tool 1',
			),
			array(
				'id'    => 'flaticon-twitter39',
				'name'  => 'Twitter',
			),
			array(
				'id'    => 'flaticon-vimeo22',
				'name'  => 'Vimeo',
			),
			array(
				'id'    => 'flaticon-vk6',
				'name'  => 'VK',
			),
			array(
				'id'    => 'flaticon-wordpress16',
				'name'  => 'Wordpress',
			),
			array(
				'id'    => 'flaticon-youtube33',
				'name'  => 'Youtube',
			),
		);

		/**
		 * Filter genericon items
		 *
		 * @since 0.1.0
		 * @param array $items Icon names.
		 */
		$items = apply_filters( 'icon_picker_flaticon_items', $items );

		return $items;
	}
}
