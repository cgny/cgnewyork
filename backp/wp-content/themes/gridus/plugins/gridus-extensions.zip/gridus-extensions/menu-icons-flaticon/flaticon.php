<?php
/**
 * Flaticon
 */


require_once Menu_Icons::get( 'dir' ) . 'includes/type-fonts.php';

/**
 * Icon type: Flaticon
 */
class Menu_Icons_Type_Flaticon extends Menu_Icons_Type_Fonts {

	/**
	 * Holds icon type
	 *
	 * @since  0.1.0
	 * @access protected
	 * @var    string
	 */
	protected $type = 'fonticon';

	/**
	 * Holds icon label
	 *
	 * @since  0.1.0
	 * @access protected
	 * @var    string
	 */
	protected $label = 'Fonticon';

	/**
	 * Holds icon version
	 *
	 * @since  0.1.0
	 * @access protected
	 * @var    string
	 */
	protected $version = '1.0';


	/**
	 * Class constructor
	 *
	 * @since 0.1.0
	 * @param array $types Icon Types
	 * @return array
	 */
	public function __construct( Array $args ) {
		$this->stylesheet = $args['stylesheet'];
		parent::__construct();
	}


	/**
	 * Icon Names
	 *
	 * @since  0.1.0
	 * @return array
	 */
	public function get_names() {
		return array(
			array(
				'key'   => 'all',
				'label' => 'All',
				'items' => array(
					'flaticon-arrows'           => __( 'Arrows', 'menu-icons-flaticon' ),
					'flaticon-arrows-1'         => __( 'Arrows 1', 'menu-icons-flaticon' ),
					'flaticon-arrows-2'         => __( 'Arrows 2', 'menu-icons-flaticon' ),
					'flaticon-arrows-3'         => __( 'Arrows 3', 'menu-icons-flaticon' ),
					'flaticon-arrows-4'         => __( 'Arrows 4', 'menu-icons-flaticon' ),
					'flaticon-behance7'         => __( 'Behance', 'menu-icons-flaticon' ),
					'flaticon-bird97'           => __( 'Bird', 'menu-icons-flaticon' ),
					'flaticon-book-bag2'        => __( 'Bag', 'menu-icons-flaticon' ),
					'flaticon-circle'           => __( 'Circle', 'menu-icons-flaticon' ),
					'flaticon-circle-1'         => __( 'Circle 1', 'menu-icons-flaticon' ),
					'flaticon-circle-2'         => __( 'Circle 2', 'menu-icons-flaticon' ),
					'flaticon-circle-3'         => __( 'Circle 3', 'menu-icons-flaticon' ),
					'flaticon-circle-4'         => __( 'Circle 4', 'menu-icons-flaticon' ),
					'flaticon-circle-5'         => __( 'Circle 5', 'menu-icons-flaticon' ),
					'flaticon-circle-6'         => __( 'Circle 6', 'menu-icons-flaticon' ),
					'flaticon-clipboard80'      => __( 'Clipboard', 'menu-icons-flaticon' ),
					'flaticon-clock'            => __( 'Clock', 'menu-icons-flaticon' ),
					'flaticon-clocks18'         => __( 'Clocks', 'menu-icons-flaticon' ),
					'flaticon-download149'      => __( 'Download', 'menu-icons-flaticon' ),
					'flaticon-download167'      => __( 'Download', 'menu-icons-flaticon' ),
					'flaticon-earphones18'      => __( 'Earphones', 'menu-icons-flaticon' ),
					'flaticon-facebook45'       => __( 'Facebook', 'menu-icons-flaticon' ),
					'flaticon-github-logo-silhouette-in-a-square' => __( 'GitHub', 'menu-icons-flaticon' ),
					'flaticon-google111'        => __( 'Google', 'menu-icons-flaticon' ),
					'flaticon-graduation61'     => __( 'Graduation', 'menu-icons-flaticon' ),
					'flaticon-graduation9'      => __( 'Graduation', 'menu-icons-flaticon' ),
					'flaticon-identification28' => __( 'Identification', 'menu-icons-flaticon' ),
					'flaticon-graduation9'      => __( 'Graduation', 'menu-icons-flaticon' ),
					'flaticon-insignia'         => __( 'Insignia', 'menu-icons-flaticon' ),
					'flaticon-instagram14'      => __( 'Instagram', 'menu-icons-flaticon' ),
					'flaticon-internet'         => __( 'Internet', 'menu-icons-flaticon' ),
					'flaticon-linkedin22'       => __( 'Linkedin', 'menu-icons-flaticon' ),
					'flaticon-odnolassniki2'    => __( 'Odnolassniki', 'menu-icons-flaticon' ),
					'flaticon-painting62'       => __( 'Painting', 'menu-icons-flaticon' ),
					'flaticon-paper40'          => __( 'Paper', 'menu-icons-flaticon' ),
					'flaticon-pens15'           => __( 'Pens', 'menu-icons-flaticon' ),
					'flaticon-photo246'         => __( 'Photo', 'menu-icons-flaticon' ),
					'flaticon-photography39'    => __( 'Photography', 'menu-icons-flaticon' ),
					'flaticon-pie-graph'        => __( 'Pie graph', 'menu-icons-flaticon' ),
					'flaticon-pinterest28'      => __( 'Pinterest', 'menu-icons-flaticon' ),
					'flaticon-placeholders4'    => __( 'Placeholders', 'menu-icons-flaticon' ),
					'flaticon-profile5'         => __( 'Profile', 'menu-icons-flaticon' ),
					'flaticon-shopping-carts6'  => __( 'Shopping carts', 'menu-icons-flaticon' ),
					'flaticon-sign'             => __( 'Sign', 'menu-icons-flaticon' ),
					'flaticon-soundcloud8'      => __( 'Soundcloud', 'menu-icons-flaticon' ),
					'flaticon-stack-overflow'   => __( 'Stack Overflow', 'menu-icons-flaticon' ),
					'flaticon-stats47'          => __( 'Stats', 'menu-icons-flaticon' ),
					'flaticon-stats48'          => __( 'Stats', 'menu-icons-flaticon' ),
					'flaticon-symbol'           => __( 'Symbol', 'menu-icons-flaticon' ),
					'flaticon-three'            => __( 'Three', 'menu-icons-flaticon' ),
					'flaticon-three-1'          => __( 'Three 1', 'menu-icons-flaticon' ),
					'flaticon-three-2'          => __( 'Three 2', 'menu-icons-flaticon' ),
					'flaticon-tool'             => __( 'Tool', 'menu-icons-flaticon' ),
					'flaticon-tool-1'           => __( 'Tool 1', 'menu-icons-flaticon' ),
					'flaticon-twitter39'        => __( 'Twitter', 'menu-icons-flaticon' ),
					'flaticon-vimeo22'          => __( 'Vimeo', 'menu-icons-flaticon' ),
					'flaticon-vk6'              => __( 'VK', 'menu-icons-flaticon' ),
					'flaticon-wordpress16'      => __( 'Wordpress', 'menu-icons-flaticon' ),
					'flaticon-youtube33'        => __( 'Youtube', 'menu-icons-flaticon' ),
				),
			),
		);
	}
}

