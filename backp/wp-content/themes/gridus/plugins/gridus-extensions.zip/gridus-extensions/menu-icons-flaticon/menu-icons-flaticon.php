<?php

/**
 * Menu Icons: Flaticon
 */


/**
 * Main plugin class
 */
final class Menu_Icons_Flaticon {

	/**
	 * Load plugin
	 *
	 * @since   0.1.0
	 * @since   0.2.0 Register to Icon Picker instead.
	 * @wp_hook action plugins_loaded
	 */
	public static function _load() {
		load_plugin_textdomain( 'menu-icons-flaticon', false, dirname( plugin_basename( __FILE__ ) ) . '/languages/' );

		if ( ! class_exists( 'Menu_Icons' ) ) {
			return;
		}

		add_filter( 'menu_icons_types', array( __CLASS__, '_register' ) );
		add_filter( 'menu_icons_settings_defaults', array( __CLASS__, '_register_defaults' ) );
		add_action( 'icon_picker_types_registry_init', array( __CLASS__, '_register_to_ip' ) );
	}

	/**
	 * Register type to Icon Picker
	 *
	 * @since   0.2.0
	 * @wp_hook action                      icon_picker_types_registry_init
	 * @param   Icon_Picker_Types_Registry  $ip_registry                     Icon_Picker_Types_Registry instance.
	 */
	public static function _register_to_ip( Icon_Picker_Types_Registry $ip_registry ) {
		require_once Icon_Picker::instance()->dir . '/includes/types/font.php';
		require_once dirname( __FILE__ ) . '/flaticon-ip.php';

		$ip_registry->add( new Icon_Picker_Type_Flaticon() );
	}

	/**
	 * Register type
	 *
	 * @since   0.1.0
	 * @wp_hook filter menu_icons_types
	 */
	public static function _register( $icon_types ) {
		if ( class_exists( 'Icon_Picker_Type_Font' ) ) {
			return $icon_types;
		}

		require_once dirname( __FILE__ ) . '/flaticon.php';

		$instance = new Menu_Icons_Type_Flaticon(
			array(
				'stylesheet' => sprintf(
					'%scss/flaticon%s.css',
					plugin_dir_url( __FILE__ ),
					Menu_Icons::get_script_suffix()
				),
			)
		);
		$icon_types = $instance->register( $icon_types );

		return $icon_types;
	}

	/**
	 * Register default types
	 */
	public static function _register_defaults() {
		return array(
			'global' => array(
				'icon_types' => array( 'flaticon' ),
			),
		);
	}

}
add_action( 'plugins_loaded', array( 'Menu_Icons_Flaticon', '_load' ) );
