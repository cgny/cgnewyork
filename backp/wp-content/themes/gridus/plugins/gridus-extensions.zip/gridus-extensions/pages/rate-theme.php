<?php

/**
 * Rate Theme Page
 */
function gridus_rate_theme_page_callback() { ?>
    <div id="rate-theme" class="wrap">
        <h2>Thank you for your order!</h2>
        <div class="notice notice-info">
            <p>We hope you enjoy your purchase.</p>
            <p>All of our products are crafted with an obsessive attention to detail.</p>
            <p>We'd love to hear your thoughts <a href="mailto:info@neuethemes.net" target="_top">info@neuethemes.net</a></p>
        </div>

        <div class="notice notice-info" style="padding-bottom: 35px;">
            <h2 style="display: inline-block">Please, do not forget to rate theme &nbsp;</h2>

            <a href="https://themeforest.net/downloads" style="text-decoration: none;" target="_blank">
                <span class="dashicons dashicons-star-filled"></span>
                <span class="dashicons dashicons-star-filled"></span>
                <span class="dashicons dashicons-star-filled"></span>
                <span class="dashicons dashicons-star-filled"></span>
                <span class="dashicons dashicons-star-filled"></span>
            </a>
            <p>P.S. Every positive feedback increases the chances of sale, each sale brings extra funds to develop new features and product support, which ultimately makes you a little happier.</p>
            <div style="overflow: hidden; padding: 25px 0 15px 0;">
                <img src="<?php echo plugins_url( '../assets/images/rateme-banner.jpg', __FILE__ ) ?>"/>
            </div>
            <a class="button" href="https://themeforest.net/downloads" target="_blank" style="background-color:#f2b827; color:#fff; width:100px; text-align:center; height: 35px;line-height: 35px; font-size: 14px">Rate Now!</a>
        </div>

        <br class="clear">
    </div>
<?php }



function gridusAddActivateNotification() {
    $nonce = wp_create_nonce("gridus_ext");
    ?>

    <div id="rate-theme-message" class="updated below-h2">
        <a href="javascript:void(0);" style="float: right;padding-top: 9px;" id="gridus-ext-dismiss-notice"><b>X</b></a>
        <p>
            Please, do not forget to rate the <a href="https://themeforest.net/downloads" target="_blank">Gridus Wordpress theme</a> &nbsp;
            <a href="https://themeforest.net/downloads" style="text-decoration: none;" target="_blank">
                <span class="dashicons dashicons-star-filled"></span>
                <span class="dashicons dashicons-star-filled"></span>
                <span class="dashicons dashicons-star-filled"></span>
                <span class="dashicons dashicons-star-filled"></span>
                <span class="dashicons dashicons-star-filled"></span>
            </a>
        </p>
    </div>
    <script type="text/javascript">
        jQuery('#gridus-ext-dismiss-notice').click(function(){
            var objData = {
                action:"gridus_ext_notice",
                nonce:'<?php echo $nonce; ?>',
            };

            jQuery.ajax({
                type:"post",
                url:ajaxurl,
                dataType: 'json',
                data:objData
            });

            jQuery('#rate-theme-message').hide();
        });
    </script>
<?php }

$notice_date = get_theme_mod('rate-theme-notice', 'null');
if ( $notice_date === 'null' ) {
    set_theme_mod('rate-theme-notice', strtotime("+10 minutes"));
}

if ($notice_date !== 'false' && $notice_date < strtotime('now')) {
    add_action('admin_notices', 'gridusAddActivateNotification');
}

function gridus_ext_notice_ajax_callback() {
    set_theme_mod('rate-theme-notice', 'false');
}

add_action('wp_ajax_gridus_ext_notice', 'gridus_ext_notice_ajax_callback');
