<?php
/**
 * Demo Content Page
 */
function demo_content_page_callback() { ?>
    <?php
    $is_tgmpa_complete = class_exists( 'TGM_Plugin_Activation' ) ? TGM_Plugin_Activation::$instance->is_tgmpa_complete() : false;
    $demo_content_is_imported = get_theme_mod('demo_content_is_imported');
    ?>

    <div class="wrap">
        <h2><?php echo esc_html__('Demo Content', 'gridus') ?></h2>
        <?php if (!$is_tgmpa_complete && !$demo_content_is_imported) : ?>
            <div class="error notice">
                <p><?php echo esc_html__( 'Please install required plugins before importing.', 'gridus' ); ?></p>
            </div>
        <?php endif; ?>
        <div class="notice notice-info">
            <p><?php echo esc_html__('Make your website look exactly the same as demo version and then customize it to your requirements easily.', 'gridus') ?></p>
        </div>

        <?php if ( $demo_content_info = get_theme_mod('demo_content_info') ) { ?>
            <div class="notice notice-warning">
                <p><?php echo $demo_content_info ?></p>
            </div>
            <?php set_theme_mod('demo_content_info', null); } ?>

        <div style="margin-top: 20px;">
            <form name="demo-content" method="POST" action="<?php echo admin_url( 'admin.php' ); ?>">
                <input type="hidden" name="action" value="gridus_demo" />
                <div style="border: 1px solid #dfdfdf; background-color: #f5f5f5; padding: 0 10px; max-width: 610px; position: relative">
                    <div style="position: absolute; right: 10px; top: 12px;">
                        <button type="submit" name="demo_content_is_imported" class="button button-primary" <?php echo (!$is_tgmpa_complete && !$demo_content_is_imported) ? 'disabled' : ''?>
                                value="<?php echo $demo_content_is_imported ? esc_html__('Remove', 'gridus') : esc_html__('Import', 'gridus'); ?>">
                            <?php echo $demo_content_is_imported ? esc_html__('Remove', 'gridus') : esc_html__('Import', 'gridus'); ?>
                        </button>
                    </div>
                    <h3>
                        <?php
                        echo $demo_content_is_imported ? '[' . esc_html__('IMPORTED', 'gridus') . "] " : '';
                        echo esc_html__('Gridus demo content', 'gridus');
                        ?>
                    </h3>
                </div>
            </form>
            <div>
                <img style="border: 1px solid #dfdfdf; border-top: none;" src="<?php echo plugins_url( '../assets/images/gridus-demo.jpg', __FILE__ ) ?>"/>
            </div>
        </div>
    </div>

    <script>
        (function ($) {
            'use strict';

            $(document).ready(function () {
                $('input[name="demo_content_is_imported"]').on('click', function() {
                    $("body").css("cursor", "progress");

                    var button = $(this);
                    button.parents('form').submit();
                    setTimeout(function() {
                        button.attr('disabled', 'disabled');
                    }, 10)
                });
            });

        })(jQuery);

    </script>

<?php }
