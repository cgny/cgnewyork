=== Gridus Extensions ===
Contributors: neuethemes
Author link: http://neuethemes.net
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl.html

# Description

Gridus Extensions contains the necessary shortcodes and widgets for Gridus WP Theme.
