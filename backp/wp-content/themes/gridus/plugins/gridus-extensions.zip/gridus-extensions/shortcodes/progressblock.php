<?php
// Progressblock

if (!function_exists('gridus_progressblock_shortcode')) {

    function gridus_progressblock_shortcode($atts, $content = null)
    {
        list($header, $val) = array_values(shortcode_atts(array(
            'header' => esc_html__('Prototyping', 'gridus'),
            'val' => 72.5
        ), $atts));

        return '<div class="progressblock">
                    <div class="progressbar" data-animate="false">
                        <div class="circle font-accident-one-normal" data-percent="' . floatval($val) . '">
                            <div></div>
                            <h4 class="font-accident-one-normal uppercase">' . esc_html($header) . '</h4>
                            <p class="small">' . wp_kses($content, 'post') . '</p>
                        </div>
                    </div>
                    <div class="divider-dynamic"></div>
                </div>';
    }

    add_shortcode('progressblock', 'gridus_progressblock_shortcode');
}