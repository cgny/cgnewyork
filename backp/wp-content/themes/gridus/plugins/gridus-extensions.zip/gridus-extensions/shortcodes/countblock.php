<?php
// Countblock

if (!function_exists('gridus_countblock_shortcode')) {

    function gridus_countblock_shortcode($atts, $content = null)
    {
        list($header, $icon, $val) = array_values(shortcode_atts(array(
            'header' => esc_html__('Websites', 'gridus'),
            'icon' => 'flaticon-badges2',
            'val' => 650
        ), $atts));

        return '<div class="count">
                    <div class="count-icon">
                        <i class="' . esc_attr($icon) . '"></i>
                    </div>
                    <span class="integers digit font-accident-two-normal">' . absint($val) . '</span>
                    <div class="count-text font-accident-one-bold">' . esc_html($header) . '</div>
                </div>';
    }

    add_shortcode('countblock', 'gridus_countblock_shortcode');
}