<?php
// Dividewhite

if (!function_exists('gridus_dividewhite_shortcode')) {

    function gridus_dividewhite_shortcode($atts)
    {
        list($val) = array_values(shortcode_atts(array(
            'val' => 1
        ), $atts));

        return '<div class="dividewhite' . absint($val) . '"></div>';
    }

    add_shortcode('dividewhite', 'gridus_dividewhite_shortcode');
}
