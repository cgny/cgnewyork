<?php
// Contact

if (!function_exists('gridus_contact_shortcode')) {

    function gridus_contact_shortcode($atts, $content = null)
    {
        list($key, $val) = array_values(shortcode_atts(array(
            'key' => esc_html__('Phone', 'gridus'),
            'val' => esc_html__('1 234 567-64-35', 'gridus'),
        ), $atts));

        if (filter_var($val, FILTER_VALIDATE_URL) !== false) {
            $val = '<a href="' . $val . '">' . $val . '</a>';
        }

        return '<div class="row">
                    <div class="col-sm-2"><span class="font-accident-two-bold uppercase">' . $key . ':</span></div>
                    <div class="col-sm-10"><p class="small">' . $val . '</p></div>
                </div>';
    }

    add_shortcode('contact', 'gridus_contact_shortcode');
}