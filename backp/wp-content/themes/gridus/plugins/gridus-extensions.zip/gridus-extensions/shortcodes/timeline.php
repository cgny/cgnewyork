<?php
// Timeline

if (!function_exists('gridus_timeline_shortcode')) {

    function gridus_timeline_shortcode($atts, $content = null)
    {
        list($category, $limit, $order) = array_values(shortcode_atts(array(
        	'category' => '*',
            'limit' => 9,
            'order' => 'ASC'
        ), $atts));

        $order = ($order !== 'ASC' && $order !== 'DESC') ? 'ASC' : $order;

        $timeline = null;

        $args = array(
            'post_type' => 'timeline',
            'posts_per_page' => $limit,
            'post_status' => 'publish',
            'meta_key' => 'start',
            'orderby' => 'meta_value',
            'order' => $order
        );

	    if ($category != '*') {
		    $category = str_replace('.', '', $category);
		    $args['tax_query'] = array(
			    array(
				    'taxonomy' => 'category',
				    'field' => 'slug',
				    'terms' => $category
			    ),
		    );
	    }

        $inverted = true;
        $timeline_items = get_posts($args);

        foreach ($timeline_items as $key => $post) {

            $image[0] = null;
            if (has_post_thumbnail($post->ID)) {
                $image = wp_get_attachment_image_src(get_post_thumbnail_id($post->ID), 'single-post-thumbnail');
            }

            $inverted = $inverted ? false : 'class="timeline-inverted"';

            if (function_exists('get_fields')) {
                $fields = get_fields($post->ID);
                $fields['start'] = gridus_date_format('M Y', $fields['start']);
                $fields['end'] = gridus_date_format('M Y', $fields['end']);
            } else {
                $fields = array();
            }

            $bg_style = $image[0] ? 'background-image: url(\'' . $image[0] . '\');' : '';

            $timeline .=
                '<li ' . wp_kses($inverted, 'default') . '>
                    <div class="timeline-badge primary"><i class="flaticon-clocks18"></i></div>
                    <div class="timeline-panel">
                        <p class="timeline-time fontcolor-invert"><i class="glyphicon glyphicon-time"></i> ' . esc_html($fields['start'] . ' - ' . $fields['end']) . '</p>
                        <div class="timeline-photo timeline-bg" style="' . esc_html($bg_style) . '"></div>
                        <div class="timeline-heading">
                            <h3 class="font-accident-two-normal uppercase">' . esc_html($post->post_title) . '</h3>
                            <h6 class="uppercase">' . esc_html($fields['position']) . '</h6>
                        </div>
                        <div class="timeline-content">' . wp_kses($post->post_content, "post") . '</div>
                    </div>
                </li>';
        }


        return '<ul class="timeline-vert timeline-light">' . $timeline . '</ul>';

    }

    add_shortcode('timeline', 'gridus_timeline_shortcode');
}