<?php
// Testimonial

if (!function_exists('gridus_testimonial_shortcode')) {

    function gridus_testimonial_shortcode($atts, $content = null)
    {
        list($author, $company, $image) = array_values(shortcode_atts(array(
            'author' => esc_html__('Hans Zimmer', 'gridus'),
            'company' => esc_html__('Apple Inc.', 'gridus'),
            'image' => esc_html__('/wp-content/uploads/2016/03/userpic04.jpg', 'gridus')
        ), $atts));

        return '<div class="row testimonial">
                    <div class="col-xs-3">
                        <img src="' . esc_attr($image) . '" class="img-responsive img-circle author-userpic" alt="' . esc_attr($author) . '">
                    </div>
                    <div class="col-xs-9">
                        <h5 class="font-accident-one-bold text-left uppercase">' . esc_html($author) . '</h5>
                        <p class="small company">' . esc_html($company) . '</p>
                        <p class="text-left small">' . wp_kses($content, 'post') . '</p>
                    </div>
                </div>
                <div class="divider-dynamic"></div>';
    }

    add_shortcode('testmonial', 'gridus_testimonial_shortcode'); // backward compatibility
    add_shortcode('testimonial', 'gridus_testimonial_shortcode');
}