<?php
// Infoblock

if (!function_exists('gridus_infoblock_shortcode')) {

    function gridus_infoblock_shortcode($atts, $content = null)
    {
        list($header, $icon) = array_values(shortcode_atts(array(
            'header' => esc_html__('Creative', 'gridus'),
            'icon' => 'flaticon-photo246'
        ), $atts));

        return '<div class="row infoblock">
                    <div class="col-sm-1 col-md-3">
                        <i class="' . esc_attr($icon) . '"></i>
                    </div>
                    <div class="col-sm-11 col-md-9">
                        <h5 class="font-accident-one-bold uppercase">' . esc_html($header) . '</h5>

                        <div class="dividewhite1"></div>
                        <p class="small">' . wp_kses($content, 'post') . '</p>
                    </div>
                </div>';
    }

    add_shortcode('infoblock', 'gridus_infoblock_shortcode');
}