<?php
// Inner row and column

if (shortcode_exists('row') && !function_exists('gridus_row_inner_shortcode')) {
    function gridus_row_inner_shortcode($params, $content = null)
    {
        if (function_exists('osc_theme_row')) {
            return osc_theme_row($params, $content);
        }
    }

    add_shortcode('row_inner', 'gridus_row_inner_shortcode');
}

if (shortcode_exists('column') && !function_exists('gridus_column_shortcode')) {
    remove_shortcode('column');

    function gridus_column_shortcode($params, $content = null) {
        extract(shortcode_atts(array(
            'md' => '',
            'sm' => '',
            'xs' => '',
            'lg' => '',
            'mdoff' => '',
            'smoff' => '',
            'xsoff' => '',
            'lgoff' => '',
            'mdhide' => '',
            'smhide' => '',
            'xshide' => '',
            'lghide' => '',
            'mdclear' => '',
            'smclear' => '',
            'xsclear' => '',
            'lgclear' => '',
            'off' => '',
            'class' => ''
        ), $params));


        $arr = array('md', 'xs', 'sm');
        $classes = array();
        foreach ($arr as $k => $aa) {
            if (${$aa} == 12 || ${$aa} == '') {
                $classes[] = 'col-' . $aa . '-12';
            } else {
                $classes[] = 'col-' . $aa . '-' . ${$aa};
            }
        }
        $arr2 = array('mdoff', 'smoff', 'xsoff', 'lgoff');
        foreach ($arr2 as $k => $aa) {
            $nn = str_replace('off', '', $aa);
            if (${$aa} == 0 || ${$aa} == '') {
                //$classes[] = '';
            } else {
                $classes[] = 'col-' . $nn . '-offset-' . ${$aa};
            }
        }
        $arr2 = array('mdhide', 'smhide', 'xshide', 'lghide');
        foreach ($arr2 as $k => $aa) {
            $nn = str_replace('hide', '', $aa);
            if (${$aa} == 'yes') {
                $classes[] = 'hidden-' . $nn;
            }
        }
        $arr2 = array('mdclear', 'smclear', 'xsclear', 'lgclear');
        foreach ($arr2 as $k => $aa) {
            $nn = str_replace('clear', '', $aa);
            if (${$aa} == 'yes') {
                $classes[] = 'clear-' . $nn;
            }
        }
        if ($off != '') {
            $classes[] = 'col-lg-offset-'.$off;
        }

        if ($off != '') {
            $classes[] = 'col-lg-offset-'.$off;
        }

        $classes[] = $class;

        $result = '<div class="col-lg-' . $lg . ' ' . implode(' ', $classes) . EBS_CONTAINER_CLASS.'">';
        $result .= do_shortcode($content);
        $result .= '</div>';

        return $result;
    }

    add_shortcode('column', 'gridus_column_shortcode');
    add_shortcode('column_inner', 'gridus_column_shortcode');
}