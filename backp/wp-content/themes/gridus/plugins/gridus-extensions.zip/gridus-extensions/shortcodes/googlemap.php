<?php
// Google Map

if (!function_exists('gridus_google_map_shortcode')) {

    function gridus_google_map_shortcode($atts, $content = null)
    {
        list($lat, $lng) = array_values(shortcode_atts(array(
            'lat' => 52.5075419,
            'lng' => 13.4261419
        ), $atts));

        return '<div id="gm-panel">
                    <div id="google-map" class="bigmap" data-lat="' . esc_attr($lat) . '" data-lng="' . esc_attr($lng) . '"></div>
                </div>';
    }

    add_shortcode('google_map', 'gridus_google_map_shortcode');
}