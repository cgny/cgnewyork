<?php
// Blog

if (!function_exists('gridus_blog_shortcode')) {

    function gridus_blog_filters($params)
    {
        $filter_items = '';

        if ( $params['categories'] == '*' || count($params['categories']) > 1 ) {
            $filter_items = '<li><a href="#all" data-filter="*">' . esc_html__('All categories', 'gridus') . '</a></li>';
        }

        $post_categories = get_categories();
        foreach ($post_categories as $key => $term) {
            if ( $params['categories'] == '*' || array_search( $term->slug, $params['categories'] ) !== false ) {
                $active = !empty($_SESSION['gridusSession']['blog_categories']) && $_SESSION['gridusSession']['blog_categories'] == $term->slug ? 'active' : '';
                $filter_items .= '<li><a href="#' . esc_attr( $term->slug ) . '" data-filter=".' . esc_attr( $term->slug ) . '" class="' . $active . '">' . esc_html( $term->name ) . '</a></li>';
            }
        }

        if ( empty($filter_items) ) return '';

        $filters = '<div id="isotope-filters" class="port-filter port-filter-light text-center">
                        <ul>' . $filter_items . '</ul>
                    </div>';

        return $filters;
    }

    function gridus_blog_grid_items($params)
    {
        if ( !(defined( 'DOING_AJAX' ) && DOING_AJAX) && !empty($_SESSION['gridusSession']['blog_categories']) ) {
            $params['categories'] = $_SESSION['gridusSession']['blog_categories'];
            $params['limit'] = $_SESSION['gridusSession']['blog_range'];
        }

        $grid_items = '';

        $args = array(
            'posts_per_page' => $params['limit'],
            'post_type' => 'post',
            'post_status' => 'publish',
            'orderby' => $params['orderby'],
            'order' => $params['order'],
            'offset' => $params['offset'],
        );

        if ($params['categories'] != '*') {
            $params['categories'] = str_replace('.', '', $params['categories']);
            $args['tax_query'] = array(
                array(
                    'taxonomy' => 'category',
                    'field' => 'slug',
                    'terms' => $params['categories']
                ),
            );
        }

        $_SESSION['gridusSession']['blog_categories'] = $params['categories'];
        $_SESSION['gridusSession']['blog_range'] = absint($params['offset']) + absint($params['limit']);

        $imgOnLoad = (defined('DOING_AJAX') && DOING_AJAX) ? 'gridusImgloader()' : '';

        global $post;
        $post_items = get_posts($args);

        $load_more = is_array($post_items) && (count($post_items) == absint($params['limit'])) ? true : false;

        foreach ($post_items as $post) {
            setup_postdata($post);

            $category_classes = array();
            $category_string = array();
            $post_categories = wp_get_post_categories(get_the_ID());

            if (!empty($post_categories)) {
                $last_category = array_pop($post_categories);
                foreach ($post_categories as $category) {
                    $category = get_category($category);
                    $category_classes[] = $category->slug;
                    $category_string[] = '<span><a href="#' . esc_attr($category->slug) . '" data-filter=".' . esc_html($category->slug) . '">' . esc_html($category->name) . '</a>,</span>';
                }
                $last_category = get_category($last_category);
                $category_classes[] = $last_category->slug;
                $category_string[] = '<span><a href="#' . esc_attr($last_category->slug) . '" data-filter=".' . esc_html($last_category->slug) . '">' . esc_html($last_category->name) . '</a></span>';
            }

            $grid_items .=
                '<div class="grid-item grid-sizer ' . esc_attr(implode(' ', $category_classes)) . ' col-md-4 col-sm-6">
                     <div class="item-wrap">
                        <figure class="">
                           <div class="popup-call">
                              <a href="' . get_the_post_thumbnail_url(null, 'full') . '" class="gallery-item"><i class="flaticon-arrows-3"></i></a>
                           </div>
                           <a href="' . get_the_permalink() . '">
                               ' . get_the_post_thumbnail(null, 'full', array('class' => 'img-responsive', 'onload' => $imgOnLoad)) . '
                           </a>
                           <figcaption>
                              <div class="post-meta"><span>by ' . get_the_author_posts_link() . ',</span> <span>' . get_the_date("F j, Y") . '</span></div>
                              <div class="post-header">
                                 <h5><a href="' . get_permalink() . '">' . get_the_title() . '</a></h5>
                              </div>
                              <div class="post-entry">
                                 <p>' . get_the_excerpt() . '</p>
                              </div>
                              <div class="post-tag pull-left">' . implode('', $category_string) . '</div>
                              <div class="post-more-link pull-right"><a href="' . get_permalink() . '">More<i class="fa fa-long-arrow-right right"></i></a></div>
                           </figcaption>
                        </figure>
                     </div>
                  </div>';
        }
        wp_reset_postdata();

        return array( 'grid_items' => $grid_items, 'load_more' => $load_more );
    }

    function gridus_blog_shortcode($atts, $content = null)
    {
        $params = shortcode_atts(array(
            'limit' => 9,
            'orderby' => 'date',
            'order' => 'ASC',
            'offset' => 0,
            'categories' => '*',
            'hide_filters' => '0',
            'just_items' => '0'
        ), $atts);

        $params['limit'] = absint($params['limit']);
        $params['offset'] = absint($params['offset']);
        $params['order'] = strtoupper($params['order']) !== 'DESC' ? 'ASC' : 'DESC';

        if ( $params['categories'] != '*' ) {
            $params['categories'] = array_map(function($item) {
                return ltrim($item);
            }, explode(',', $params['categories']));
        }

        if ( $params['just_items'] === '1' ) {
            return gridus_blog_grid_items($params);
        }

        $filters = '';

        if ( $params['hide_filters'] === '0' ) {
            $filters = gridus_blog_filters($params);
        }

        $divider = '<div class="dividewhite4"></div>';

        $result = gridus_blog_grid_items($params);

        $data_category = is_array($params['categories']) ? $params['categories'][0] : '*';

        $grid = '<div class="grid container-fluid text-center">
                    <div id="posts" class="row popup-container" data-category="' . $data_category . '" data-offset="' . $params['offset'] . '" data-order="' . $params['order'] . '" data-orderby="' . $params['orderby'] . '" data-limit="' . $params['limit'] . '">
                        ' . $result['grid_items'] . '
                    </div>
                 </div>
                 <div class="dividewhite4"></div>
                 <div class="fullwidth text-center">
                     <input type="submit" value="Load More" class="blog-more' . ($result['load_more'] ? "" : " hidden") . '" name="more_posts">
                 </div>';

        return $filters . $divider . $grid;

    }

    add_shortcode('blog', 'gridus_blog_shortcode');
}