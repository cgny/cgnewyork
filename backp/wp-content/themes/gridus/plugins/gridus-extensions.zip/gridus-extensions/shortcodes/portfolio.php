<?php
// Portfolio

if (!function_exists('gridus_portfolio_shortcode')) {

    function gridus_portfolio_filters($params)
    {
        $filter_items = '';

        if ( $params['categories'] == '*' || count($params['categories']) > 1 ) {
            $filter_items .= '<li><a href="#all" data-filter="*">' . esc_html__('All', 'gridus') . '</a></li>';
        }

        $portfolio_categories = get_terms('portfolio_category');
        foreach ($portfolio_categories as $key => $term) {
            if ( $params['categories'] == '*' || array_search( $term->slug, $params['categories'] ) !== false ) {
                $filter_items .= '<li><a href="#' . esc_attr( $term->slug ) . '" data-filter=".' . esc_html( $term->slug ) . '">' . esc_html( $term->name ) . '</a></li>';
            }
        }

        if ( empty($filter_items) ) return '';

        $filters = '<div id="isotope-filters" class="port-filter port-filter-light text-center">
                        <ul>' . $filter_items . '</ul>
                    </div>';

        return $filters;
    }

    function gridus_portfolio_grid_items($params)
    {
        $grid_items = '';

        $args = array(
            'posts_per_page' => $params['limit'],
            'post_type' => 'portfolio',
            'post_status' => 'publish',
            'orderby' => $params['orderby'],
            'order' => $params['order']
        );

        if ($params['categories'] != '*') {
            $args['tax_query'] = array(
                array(
                    'taxonomy' => 'portfolio_category',
                    'field' => 'slug',
                    'terms' => $params['categories']
                ),
            );
        }

        global $post;
        $portfolio_items = get_posts($args);

        foreach ($portfolio_items as $post) {
            setup_postdata($post);

            $tags_string = array();
            $portfolio_tags = wp_get_object_terms(get_the_ID(), 'portfolio_tag');

            foreach ($portfolio_tags as $tag) {
                $tags_string[] = '#' . $tag->name;
            }

            $category_string = array();
            $portfolio_categories = wp_get_object_terms(get_the_ID(), 'portfolio_category');

            foreach ($portfolio_categories as $category) {
                $category_string[] = $category->slug;
            }

            $image[0] = null;
            if (has_post_thumbnail(get_the_ID())) {
                $image = wp_get_attachment_image_src(get_post_thumbnail_id(get_the_ID()), 'single-post-thumbnail');
            }

            $grid_items .=
                '<div class="grid-item grid-sizer ' . esc_html(implode(' ', $category_string)) . ' col-lg-3 col-md-4 col-sm-6">
                    <div class="item-wrap">
                        <figure class="effect-goliath">
                            <div class="popup-call">
                                <a href="' . esc_attr($image[0]) . '" class="gallery-item"><i class="flaticon-arrows-3"></i></a>
                            </div>
                            ' . get_the_post_thumbnail(null, 'post-thumbnail', array('class' => 'img-responsive')) .'
                            <figcaption>
                                <div class="fig-description">
                                    <h3>' . get_the_title() . '</h3>
                                    <p>' . wp_kses(implode(' ', $tags_string), 'post') . '</p>
                                </div>
                                ' . ($params['item_page'] == '1' ? '<a href="' . get_the_permalink() . '"></a>' : '') . '
                            </figcaption>
                        </figure>
                    </div>
                </div>';
        }
        wp_reset_postdata();

        return $grid_items;
    }

    function gridus_portfolio_shortcode($atts, $content = null)
    {
        $params = shortcode_atts(array(
            'limit' => 9,
            'orderby' => 'date',
            'order' => 'ASC',
            'categories' => '*',
            'hide_filters' => '0',
            'item_page' => '1',
            'hide_items' => '0',
            'just_items' => '0'
        ), $atts);

        $params['limit'] = absint($params['limit']);
        $params['order'] = strtoupper($params['order']) !== 'DESC' ? 'ASC' : 'DESC';
        $params['item_page'] = $params['item_page'] != '0' ? '1' : '0';
        $params['categories'] = $params['categories'] ? $params['categories'] : '*';

        if ($params['categories'] != '*') {
            $params['categories'] = array_map(function($item) {
                return ltrim($item);
            }, explode(',', $params['categories']));
        }

        if ( $params['just_items'] === '1' ) {
            return gridus_portfolio_grid_items($params);
        }

        set_theme_mod('portfolio_hide_items', $params['hide_items']);

        $filters = '';

        if ( $params['hide_filters'] === '0' ) {
            $filters = gridus_portfolio_filters($params);
            $filters .= '<div class="dividewhite4"></div>';
        }

        $grid_items = gridus_portfolio_grid_items($params);

        $grid = '<div class="grid container text-center">
                    <div id="posts" class="row popup-container">' . wp_kses($grid_items, 'post') . '</div>
                 </div>';

        return $filters . $grid;
    }


    add_shortcode('portfolio', 'gridus_portfolio_shortcode');
}