<?php
/**
 * Gridus social widget
 */
class Gridus_Social_Widget extends WP_Widget {

    var $defaults;

    function __construct() {
        $widget_ops = array( 'classname' => 'gridus_social_widget', 'description' => esc_html__('Display your social icons with this widget', 'gridus') );
        $control_ops = array( 'id_base' => 'gridus_social_widget' );
        parent::__construct('gridus_social_widget', esc_html__('Gridus Social Widget', 'gridus'), $widget_ops, $control_ops );

        add_action( 'admin_enqueue_scripts', array($this,'enqueue_admin_scripts'));

        $this->defaults = array(
            'title' => esc_html__('Follow Me', 'gridus'),
            'content' => '',
            'social' => array()
        );
    }

    function enqueue_admin_scripts(){
        wp_enqueue_script( 'gridus-social-widget-js', plugins_url( 'social.js', __FILE__), array( 'jquery'), '1.0' );
        wp_enqueue_style(  'font-awesome', get_template_directory_uri() . '/assets/vendor/fontawesome/css/font-awesome.min.css', array(), '20150825' );
    }

    function widget( $args, $instance ) {

        extract( $args );

        $instance = wp_parse_args( (array) $instance, $this->defaults );
        $social = $this->get_social();

        $title = apply_filters('widget_title', $instance['title'] );
        echo $before_widget;

        if ( !empty($title) ) {
            echo $before_title . $title . $after_title;
        }
        ?>

        <?php if(!empty($instance['content'])) : ?>
            <?php echo wpautop($instance['content']);?>
        <?php endif; ?>

        <?php if(!empty($instance['social'])): ?>
            <?php foreach($instance['social'] as $item) : ?>
                <div class="inline-block">
                    <a href="<?php echo esc_attr($item['url']); ?>">
                        <i class="<?php echo esc_attr($social[$item['icon']]['icon']);?>" title="<?php echo esc_attr($social[$item['icon']]['name']);?>" aria-hidden="true"></i>
                    </a>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>

        <?php
        echo $after_widget;
    }


    function update( $new_instance, $old_instance ) {
        $instance = $old_instance;
        $instance['title'] = strip_tags( $new_instance['title'] );
        $instance['content'] = $new_instance['content'];
        $instance['social'] = array();
        if (!empty($new_instance['social_icon'])) {
            $protocols = wp_allowed_protocols();
            for ($i=0; $i < (count($new_instance['social_icon']) - 1); $i++){
                $temp = array('icon' => $new_instance['social_icon'][$i], 'url' => esc_url($new_instance['social_url'][$i], $protocols));
                $instance['social'][] = $temp;
            }
        }

        return $instance;
    }

    function form( $instance ) {

        $instance = wp_parse_args( (array) $instance, $this->defaults );

        $social_links = $this->get_social();
        ?>

        <p>
            <label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php esc_html_e('Title', 'gridus'); ?>:</label>
            <input id="<?php echo $this->get_field_id( 'title' ); ?>" type="text" name="<?php echo $this->get_field_name( 'title' ); ?>" value="<?php echo $instance['title']; ?>" class="widefat" />
        </p>
        <p>
            <label for="<?php echo $this->get_field_id( 'content' ); ?>"><?php esc_html_e('Introduction text (optional)', 'gridus'); ?>:</label>
            <textarea id="<?php echo $this->get_field_id( 'content' ); ?>" rows="2" name="<?php echo $this->get_field_name( 'content' ); ?>" class="widefat"><?php echo $instance['content']; ?></textarea>
        </p>

        <h4><?php esc_html_e('Icons', 'gridus'); ?>:</h4>
        <p>
        <ul class="gridus_social_container">
            <?php foreach($instance['social'] as $link) : ?>
                <li>
                    <?php $this->draw_social($this, $social_links, $link); ?>
                </li>
            <?php endforeach; ?>
        </ul>
        </p>

        <p>
            <a href="#" class="gridus_add_social button"><?php esc_html_e('Add Icon', 'gridus'); ?></a>
        </p>

        <div class="gridus_social_clone" style="display:none">
            <?php $this->draw_social($this, $social_links); ?>
        </div>



        <?php
    }

    function draw_social($widget, $social_links, $selected = array('icon' => '', 'url' => '') ){ ?>
        <?php
        $current_social_links = current($social_links);
        $selected_icon = $selected['icon'] ? $social_links[$selected['icon']]['icon'] : $current_social_links['icon'];
        ?>

        <label for="<?php echo esc_attr($widget->get_field_name('social_icon')); ?>"><?php esc_html_e('Icon', 'gridus'); ?>:</label><br>
        <select type="text" name="<?php echo esc_attr($widget->get_field_name('social_icon')); ?>[]" value="<?php echo esc_attr($selected['icon']); ?>" style="width: 85%">
            <?php foreach($social_links as $key => $link) : ?>
                <option value="<?php echo esc_attr($key); ?>" <?php selected($key,$selected['icon']); ?> data-icon="<?php echo esc_attr($link['icon']); ?>"><?php echo esc_html($link['name']); ?></option>
            <?php endforeach; ?>
        </select>
        <i class="<?php echo esc_attr($selected_icon); ?>" style="font-size: 20px;" aria-hidden="true"></i><br>

        <label for="<?php echo esc_attr($widget->get_field_name('social_url')); ?>"><?php esc_html_e('Url ', 'gridus'); ?>:</label><br>
        <input type="text" name="<?php echo esc_attr($widget->get_field_name('social_url')); ?>[]" value="<?php echo esc_attr($selected['url']); ?>" style="width: 85%; margin-bottom: 10px" />
        <a href="#" class="gridus_remove_social" title="<?php esc_html_e('Remove', 'gridus'); ?>"><?php echo 'x'; ?></a>
    <?php }

    function get_social() {
        $social = array(
            'behance' => array(
                'name' => 'Behance',
                'icon' => 'fa fa-behance'
            ),
            'facebook' => array(
                'name' => 'Facebook',
                'icon' => 'fa fa-facebook'
            ),
            'github' => array(
                'name' => 'GitHub',
                'icon' => 'fa fa-github'
            ),
            'googleplus' => array(
                'name' => 'GooglePlus',
                'icon' => 'fa fa-google-plus'
            ),
            'instagram' => array(
                'name' => 'Instagram',
                'icon' => 'fa fa-instagram'
            ),
            'linkedin' => array(
                'name' => 'LinkedIN',
                'icon' => 'fa fa-linkedin'
            ),
            'ok' => array(
                'name' => 'Odnoklassniki',
                'icon' => 'fa fa-odnolassniki'
            ),
            'pinterest' => array(
                'name' => 'Pinterest',
                'icon' => 'fa fa-pinterest'
            ),
            'soundcloud' => array(
                'name' => 'Soundcloud',
                'icon' => 'fa fa-soundcloud'
            ),
            'stack-overflow' => array(
                'name' => 'Stack Overflow',
                'icon' => 'fa fa-stack-overflow'
            ),
            'twitter' => array(
                'name' => 'Twitter',
                'icon' => 'fa fa-twitter'
            ),
            'vimeo' => array(
                'name' => 'Vimeo',
                'icon' => 'fa fa-vimeo'
            ),
            'vk' => array(
                'name' => 'vKontakte',
                'icon' => 'fa fa-vk'
            ),
            'wordpress' => array(
                'name' => 'WordPress',
                'icon' => 'fa fa-wordpress'
            ),
            'xing' => array(
                'name' => 'XING',
                'icon' => 'fa fa-xing'
            ),
            'youtube' => array(
                'name' => 'Youtube',
                'icon' => 'fa fa-youtube'
            )
        );

        return $social;
    }
}

register_widget('Gridus_Social_Widget');