(function($) {
	$(document).ready(function ($) {
		/* Social widget handlers */

		$("body").on("click", "a.gridus_add_social", function(e) {
			e.preventDefault();
			$widgetContent = $(this).closest('.widget-content');

			var widget_holder = $(this).closest('.widget-inside');
			var cloner = widget_holder.find('.gridus_social_clone');

			widget_holder.find('.gridus_social_container').append('<li>'+cloner.html()+'</li>');

			$widgetContent.find('input[name*="title"]').change();
		});

		$("body").on("click", "a.gridus_remove_social", function(e) {
			e.preventDefault();
			$widgetContent = $(this).closest('.widget-content');

			$(this).closest('li').remove();

			$widgetContent.find('input[name*="title"]').change();
		});

		$("body").on("change", ".gridus_social_container select", function(e) {
			e.preventDefault();
			$(this).next('i').attr('class', $(this).find(':selected').data('icon'));
		})
	});

})(jQuery);