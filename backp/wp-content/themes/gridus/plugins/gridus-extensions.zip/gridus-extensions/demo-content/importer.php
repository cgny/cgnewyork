<?php

if ( isset($_POST['action']) && $_POST['action'] == 'gridus_demo' && $_POST['demo_content_is_imported'] == 'Import') {
    if ( !defined('WP_LOAD_IMPORTERS') ) define('WP_LOAD_IMPORTERS', true);
    ob_start();
}

/**
 * Demo Content action
 */
function gridus_demo_admin_action()
{
    if ($_POST['demo_content_is_imported'] == 'Import') {
        ob_end_clean();
        ob_start();

        if ( ! class_exists( 'WP_Import' ) ) {
            $class_wp_importer = GRIDUS_EXT_DIR . 'demo-content/wordpress-importer/wordpress-importer.php';
            if ( file_exists( $class_wp_importer ) ) {
                require_once $class_wp_importer;
            }
        }
        if ( ! class_exists( 'Widget_Importer_Exporter' ) ) {
            $class_wp_wie = GRIDUS_EXT_DIR . 'demo-content/widget-importer-exporter/widget-importer-exporter.php';
            if ( file_exists( $class_wp_wie ) ) {
                require_once $class_wp_wie;
            }
        }

        if ( class_exists( 'WP_Import' ) ) {

            add_action( 'import_end', 'gridus_demo_menu' );
            add_action( 'wp_import_post_data_raw', 'gridus_post_data' );
            add_action( 'wp_import_insert_post', 'gridus_home_page_detection', 10, 4 );
            add_action( 'wp_update_nav_menu_item', 'gridus_nav_menu_meta', 10, 3 );

            $import_filepath = GRIDUS_EXT_DIR . 'demo-content/files/gridus-demo-content.xml';

            $wp_import = new WP_Import();
            $wp_import->fetch_attachments = true;
            $wp_import->import($import_filepath);

            set_theme_mod('imported_demo_content', array(
                'menu_items' => $wp_import->processed_menu_items,
                'posts' => $wp_import->processed_posts,
                'terms' => $wp_import->processed_terms
            ));

            gridus_clear_footer_sidebar();

            $import_filepath = GRIDUS_EXT_DIR . 'demo-content/files/gridus-demo-widgets.wie';
            $tmp_import_filepath = GRIDUS_EXT_DIR . 'demo-content/files/tmp_gridus-demo-widgets.wie';

            copy($import_filepath, $tmp_import_filepath);

            wie_process_import_file($import_filepath);

            copy($tmp_import_filepath, $import_filepath);
            unlink($tmp_import_filepath);

            global $wp_rewrite;
            $wp_rewrite->set_permalink_structure( '/%postname%/' );
            flush_rewrite_rules();

            set_theme_mod('demo_content_is_imported', '1');

        }

        set_theme_mod('demo_content_info', ob_get_contents());

        ob_end_clean();

    } elseif ($_POST['demo_content_is_imported'] == 'Remove') {
        ob_start();

        gridus_remove_demo_content();

        echo 'All done.';

        set_theme_mod('demo_content_info', ob_get_contents());

        ob_end_clean();
    }

    wp_redirect( $_SERVER['HTTP_REFERER'] );
    exit();
}

add_action( 'admin_action_gridus_demo', 'gridus_demo_admin_action' );

/**
 * Remove Demo content
 */
function gridus_remove_demo_content() {
    $remove = get_theme_mod('imported_demo_content');

    foreach ($remove['posts'] as $post_id) {
        $attachments = get_posts( array(
            'post_type'      => 'attachment',
            'posts_per_page' => -1,
            'post_status'    => 'any',
            'post_parent'    => $post_id
        ) );

        foreach ( $attachments as $attachment ) {
            wp_delete_attachment( $attachment->ID, true );
        }

        wp_delete_post( $post_id, true );
    }

    foreach ($remove['menu_items'] as $post_id) {
        wp_delete_post( $post_id, true );
    }

    foreach ($remove['terms'] as $term_id) {
        $term = get_term( $term_id );
        wp_delete_term( $term->term_id, $term->taxonomy );
    }

    gridus_clear_footer_sidebar();

    set_theme_mod('imported_demo_content', null);
    set_theme_mod('demo_content_is_imported', '0');
}

/**
 * Replace localhost for attachments
 */
function gridus_post_data($post) {
    if ($post['post_type'] == 'page') {
        $dir = wp_upload_dir();
        $post['post_content'] = str_replace( '$localhost', $dir['baseurl'], $post['post_content'] );
    } elseif ($post['post_type'] == 'attachment') {
        $post['attachment_url'] = str_replace('$localhost', get_site_url(), $post['attachment_url']);
    }

    return $post;
}

/**
 * Detection home page
 */
function gridus_home_page_detection($post_id, $original_post_ID, $postdata, $post) {
    if ( $post['post_type'] == 'page' ) {
        if ( $post['post_title'] == esc_html__( 'Home', 'gridus' ) ) {
            update_option( 'page_on_front', $post_id );
            update_option( 'show_on_front', 'page' );
        }
    }
}

/**
 * Import nav menu custom meta
 */
function gridus_nav_menu_meta($menu_id, $menu_item_db_id, $args) {
    $menu_icons = get_post_meta($args['menu-item-object-id'], 'menu-icons', true);
    $menu_color = get_post_meta($args['menu-item-object-id'], 'menu-color', true);

    update_post_meta($menu_item_db_id, 'menu-icons', $menu_icons);
    update_post_meta($menu_item_db_id, 'menu-color', $menu_color);

    delete_post_meta($args['menu-item-object-id'], 'menu-icons');
    delete_post_meta($args['menu-item-object-id'], 'menu-color');
}

/**
 * Set demo menu location
 */
function gridus_demo_menu() {
    $locations = get_nav_menu_locations();
    $menus = wp_get_nav_menus();

    foreach ($menus as $menu) {
        $locations[ $menu->slug ] = $menu->term_id;
    }

    set_theme_mod( 'nav_menu_locations', $locations );

    $user = wp_get_current_user();
    update_user_meta( $user->ID, 'nav_menu_recently_edited', $locations['primary'] );
}

/**
 * Clear footer sidebar
 */
function gridus_clear_footer_sidebar() {
    $sidebars_widgets = get_option( 'sidebars_widgets' );
    $sidebars_widgets['sidebar-footer'] = array();
    update_option( 'sidebars_widgets', $sidebars_widgets );
}
